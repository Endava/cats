var success = 0;
var warnings = 0;
var errors = 0;
var total = 0;

var selectedFilter = "";

function styleResultAndCount(_result) {
  switch (_result) {
    case "error":
      resultCSS = "error";
      errors++;
      break;
    case "warn":
      resultCSS = "warning";
      warnings++;
      break;
    default:
      success++;
      resultCSS = "success"
  }

  return resultCSS;
}

function closeDetails() {
  $('.open').removeClass('open');
  $('.overlay').remove();
}

function initialize() {
  $("table").empty();
  //populate grid
  $("table").append(
    "<tr>" +
    "<th>ID</th>" +
    "<th>Scenario</th>" +
    "<th>Result</th>" +
    "</tr>");
  success = 0;
  warnings = 0;
  errors = 0;
  total = 0;
  fuzzerOptions = [];
  $.each(summary.summaryList, function (i, item) {
    populateTable(item);
  })

  //populate summary
  $('#summary .menu-success b').html(success);
  $('#summary .menu-warning b').html(warnings);
  $('#summary .menu-error b').html(errors);
  $('#summary .menu-total b').html(summary.summaryList.length);

  bindElements();
}

function populateTable(item) {
  var resultCSS = styleResultAndCount(item.result);

  //if id is with spaces
  var jsonCall = item.id.split(" ")[0] + item.id.split(" ")[1];

  var row = $("<tr data-id=" + jsonCall + " class=" + jsonCall + "/>");
  $("table").append(row);
  row.append($("<td>" + item.id + "</td>"));
  row.append($("<td>" + item.scenario + "</td>"));
  row.append($("<td><label class='rounded result " + resultCSS + "'>" +
    item.result + "</label></td>"));
}

$(document).keyup(function (e) {
  if (e.keyCode === 27)
    closeDetails();
});

function bindElements() {
  //populate details popup
  $("table tr").on("click", function (e) {
    e.preventDefault();
    var value = $(this).attr("data-id");
    $(".details .wrapper").empty();

    openTheStuff(eval(value));

    function openTheStuff(data) {
      //createOverlayMask
      $('body').append("<div class='overlay'></div>");

      $("body").addClass("open");

      resultCSS = styleResultAndCount(data.result);
      $("#summary .menu-filter").append('<option value=' + data.fuzzer + '>')
      var wrapperContent =
        // scenario
        ' <h5> ' + Object.keys(data)[0] + '</h5>' +
        ' <p>' + data.scenario + '</p> ' +
        // expected result
        ' <h5>Expected result</h5>' +
        ' <p> ' + data.expectedResult + '</p>' +
        // result
        ' <h5 class="d-inline"> ' + Object.keys(data)[2] + '</h5>' +
        ' <label class="rounded d-inline ' + resultCSS + '">  ' + data.result + '</label>' +
        //result details
        ' <h5>Result Details</h5>' +
        ' <p>' + data.resultDetails + '</p>' +
        ' <h5>Contract Path</h5>' +
        ' <p>' + data.path + '</p>' +
        ' <h5>Full Request Path</h5>' +
        ' <p>' + data.fullRequestPath + '</p>' +
        ' <h5>Fuzzer</h5>' +
        ' <p>' + data.fuzzer + '</p>'+
        ' <h5>Http Method</h5>' +
        ' <p>' + data.response.httpMethod + '</p>' +
        //request
        ' <h5>' + Object.keys(data)[4] + '</h5>' +
        ' <div class="subWrapper"></div>';

      var subWrapper =
        //headers
        ' <h6>' + Object.keys(data.request)[0] + '</h6>' +
        ' <pre>' + JSON.stringify(Object.values(data.request)[0], undefined, 2) + '</pre>' +
        //payload
        ' <h6>' + Object.keys(data.request)[1] + '</h6>' +
        ' <pre>' + JSON.stringify(Object.values(data.request)[1], undefined, 2) + '</pre>'

      var content =
        //response
        ' <h5>' + Object.keys(data)[5] + '</h5>' +
        ' <pre>' + JSON.stringify(data.response, undefined, 2) + '</pre>';

      $(".details .wrapper").append(wrapperContent);
      $(".details .subWrapper").append(subWrapper);
      $(".details .wrapper").append(content);
    }
  });

}
$(document).ready(function () {
  initialize();
  bindElements();
  populateFuzzerFilter();

  //filter options
  $("#summary span").on("click", function (e) {
    e.preventDefault();
    $('.active').removeClass("active");
    $("table tr").not(":first").remove();

    selectedFilter = $(e.target).attr('data-filtered');
    $(e.target).addClass("active");
    populateFuzzerFilter();
  })

  function populateFuzzerFilter() {
    $('#summary .menu-filter').empty();
    $('#summary .menu-filter').append('<option value=All>All</option>');

    $.each(summary.summaryList, function (i, item) {
      //nofilter : total
      if (selectedFilter == "") {
        populateTable(item);
        if (fuzzerOptions.includes(item.fuzzer) === false) {
          fuzzerOptions.push(item.fuzzer);
        }
      } else if (item.result === selectedFilter) {
        if (fuzzerOptions.includes(item.fuzzer) === false) {
          fuzzerOptions.push(item.fuzzer);
        }
        populateTable(item);
      }

    });

    // append options to dropdown filter
    for (let i = 0; i < fuzzerOptions.length; i++) {
      $('#summary .menu-filter').append('<option value=' + fuzzerOptions[i] + '>' + fuzzerOptions[i] + '</option>')
    }
    bindElements();
    
    //empty options array
    fuzzerOptions = [];
  }

  //dropdown filter options
  $("#summary .menu-filter").on("change", function (e) {
    e.preventDefault();

    $("table tr").not(":first").remove();
    var selectedFilter = this.value;
    var resultLabel = $("#summary span.menu.active").attr('data-filtered');
    $(function () {
      $.each(summary.summaryList, function (i, item) {
        if (selectedFilter == "All" && (item.result == resultLabel || resultLabel == "")) {
          populateTable(item);
        } else
        if (item.fuzzer === selectedFilter && item.result == resultLabel) {
          populateTable(item);
        } else
        if (resultLabel == "" && item.fuzzer === selectedFilter) {
          populateTable(item);
        }
      })
      bindElements();
    });
  });

  //bind close button
  $(".details .close").on("click", function (e) {
    closeDetails();
  });

});
